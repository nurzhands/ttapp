package nurzhands.kxtt.models;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class GameHolder extends RecyclerView.ViewHolder {
    public View view;

    public GameHolder(View view) {
        super(view);
        this.view = view;
    }
}
