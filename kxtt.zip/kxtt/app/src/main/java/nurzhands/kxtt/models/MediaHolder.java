package nurzhands.kxtt.models;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class MediaHolder extends RecyclerView.ViewHolder {
    public View view;

    public MediaHolder(View view) {
        super(view);
        this.view = view;
    }
}
