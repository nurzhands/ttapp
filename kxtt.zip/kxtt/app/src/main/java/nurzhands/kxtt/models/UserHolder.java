package nurzhands.kxtt.models;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class UserHolder extends RecyclerView.ViewHolder {
    public View view;

    public UserHolder(View view) {
        super(view);
        this.view = view;
    }
}
